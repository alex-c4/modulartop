<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <h1>Contacto</h1>
    <p>
        El usuario <b><?php echo e($name); ?> <?php echo e($lastName); ?></b> le quiere contactar, a continuación se detalla la información:
    </p>
    <p>
        <b>Correo: </b><?php echo e($email); ?>

    </p>
    <p>
        <b>Asunto: </b><?php echo e($subject); ?>

    </p>
    <p>
        <b>Mensaje: </b><?php echo e($messageContact); ?>

    </p>

</body>
</html><?php /**PATH C:\xampp\htdocs\modulartop\resources\views/emails/contactuser.blade.php ENDPATH**/ ?>