<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <h1>Suscripción a Novedades</h1>
    <p>
        El siguiente usuario se ha suscrito para recibir novedades.
        <br>
        <b><h3>{{ $email }}</h3></b></p>
</body>
</html>